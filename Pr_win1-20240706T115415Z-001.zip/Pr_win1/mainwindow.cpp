#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "prostoe_chislo.h"
#include "sinus.h"
#include "square_equal.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{

}

void MainWindow::on_comboBox_activated(int index)
{
    if (index == 0)
    {
    int x=5;
    vector<int> mnojitels;
    Prostoe_chislo pc;
    x=ui->lineEdit->text().toInt();
    bool y;
    y=pc.is_prime(x);
    if (y == true)
        ui->lineEdit_2->setText("Простое. ");
    if (y == false)
    {
        mnojitels = pc.factorize(x);
        //ui->lineEdit_2->setText("List of prime numbers");
        QString s; // res
        s += "Не простое. ";
        s += "Список простых множителей: ";
        for (int i : mnojitels)
        {
            //QString temp;
            s +=  QString::number(i);
            s += " ";
        }
        ui->lineEdit_2->setText(s);

    }
    }

    if (index == 1)
    {
        double rad, eps_m;
        SINUS teylor;
        rad = ui->lineEdit->text().toDouble();
        eps_m = ui->lineEdit_3->text().toDouble();
        double sinu;
        sinu = teylor.Auth_Sin(eps_m,rad);
        QString s1;
        s1 += QString::number(sinu);
        ui->lineEdit_2->setText(s1);

    }

    if (index == 2)
    {
        double a,b,c;
        vector<double> roots;
        Square_Equal korni;
        a = ui->lineEdit->text().toDouble();
        b = ui->lineEdit_3->text().toDouble();
        c = ui->lineEdit_4->text().toDouble();
        roots = korni.Disc(a,b,c);
        //ui->lineEdit_2->setText("List of roots");
        QString l;
        l += "Список корней кв.ур-я:  ";
        for (int j : roots)
        {
            QString temp_1;
            l += temp_1.number(j);
            l += " ";
        }
        ui->lineEdit_2->setText(l);
    }
}

