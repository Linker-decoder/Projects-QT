#ifndef PROSTOE_CHISLO_H
#define PROSTOE_CHISLO_H
#include <vector>
#include <cmath>
using namespace std;
class Prostoe_chislo
{
public:
   // Prostoe_chislo(){};

    bool is_prime(int x);

    vector<int> factorize(int x);
};

#endif // PROSTOE_CHISLO_H
