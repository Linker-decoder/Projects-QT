#include "sinus.h"


double SINUS::factorial(int x)
{
    int mul = 1;
    for (int i = 2; i <= x; i++)
    {
        mul *= i;
    }

    return mul;
}

double SINUS::Auth_Sin(double eps, double x)
{
    double a0 = x, a_n = x, n = 1, sum;
    //int i = 1;
    sum = a0;
    while (abs(a_n) >= eps)
    {
        a_n = -(a_n * x * x)/((n + 1)*(n + 2));
        sum += a_n;
        n = n + 2;
        /*sum += pow(-1, i) * pow(a_n, n) / factorial(n);
        n = n + 2;
        i++;*/
    }

    return sum;
}
