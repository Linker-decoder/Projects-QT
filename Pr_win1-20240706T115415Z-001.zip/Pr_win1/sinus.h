#ifndef SINUS_H
#define SINUS_H
#include<cmath>
using namespace std;
class SINUS
{
private:
    double factorial(int x);

public:
    double Auth_Sin(double eps, double x);

};

#endif // SINUS_H
