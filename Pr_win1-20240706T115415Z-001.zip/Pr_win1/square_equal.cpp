#include "square_equal.h"

vector<double> Square_Equal::Disc(double a, double b, double c)
{
    double x1, x2, d;
    vector<double> res;
    d = pow(b, 2) - 4 * a * c;
    if (d == 0)
    {
        res.push_back(- b / (2 * a));
    return res;
    }
    if (d < 0)
    {
        return res;
    }
    x1 = (-b - sqrt(d)) / (2 * a);
    x2 = (-b + sqrt(d)) / (2 * a);
    res.push_back(x1);
    res.push_back(x2);
    return res;
}
