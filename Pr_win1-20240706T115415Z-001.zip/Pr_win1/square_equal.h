#ifndef SQUARE_EQUAL_H
#define SQUARE_EQUAL_H
#include <vector>
#include <cmath>
using namespace std;
class Square_Equal
{
public:

    vector<double>Disc(double a, double b, double c);
};

#endif // SQUARE_EQUAL_H
