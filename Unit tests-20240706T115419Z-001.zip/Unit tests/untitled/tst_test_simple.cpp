#include <QtTest>

// add necessary includes here
#include "..\Pr_win1\prostoe_chislo.h"
#include "..\Pr_win1\sinus.h"
#include "..\Pr_win1\square_equal.h"

class test_Simple : public QObject
{
    Q_OBJECT

public:
    test_Simple();
    ~test_Simple();

private slots:
   // void initTestCase();
   // void cleanupTestCase();
    void testProst();
    void testSinus();
    void testEqual();
};

test_Simple::test_Simple() {}

test_Simple::~test_Simple() {}

void test_Simple::testProst()
{
    Prostoe_chislo number1;
    int ex1 = 2000000000;
    int el = 1;
    std::vector <int> res;
    res = number1.factorize(ex1);
    for (int& i: res)
        el *= i;
    QCOMPARE(el,ex1);

    Prostoe_chislo number2;
    int ex2 = 52;
    QCOMPARE(number2.is_prime(ex2),false);

    Prostoe_chislo number3;
    int ex3 = 29;
    QCOMPARE(number3.is_prime(ex3),true);

    Prostoe_chislo number4;
    int ex4 = 13;
    QCOMPARE(number4.is_prime(ex4),false);
}

void test_Simple::testSinus()
{
    SINUS radian1;
    double r1 = 1.45;
    double ep1 = 0.0001;
    QVERIFY(radian1.Auth_Sin(ep1,r1) - sin(r1) < ep1);

    SINUS radian2;
    double r2 = 0.7854;
    double ep2 = 0.01;
    QVERIFY(radian2.Auth_Sin(ep2,r2) - sin(r2) < ep2);
}

void test_Simple::testEqual()
{
    /*Square_Equal uzor1;
    int a = 1, b = -2, c = 1;
    std::vector<double> itog1;
    itog1 = uzor1.Disc(a,b,c);
    QCOMPARE(itog1, 1);*/

    Square_Equal uzor2;
    int a = 1, b = 5, c = 6;
    std::vector<double> korni;
    korni.push_back(2);
    korni.push_back(4);
    std::vector<double> itog2;
    itog2 = uzor2.Disc(a,b,c);
    QCOMPARE(itog2, korni);
}

QTEST_APPLESS_MAIN(test_Simple)

#include "tst_test_simple.moc"
